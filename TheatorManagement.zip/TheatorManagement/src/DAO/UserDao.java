package DAO;

import java.sql.SQLException;

import src.UserBean;

/*
 *  Application features
 */

public interface UserDao {

	public void bookTicket(UserBean u) throws SQLException; // Ticket Booking

	public void delete(int ticketId) throws SQLException; // Cancellation of
															// Ticket

	public boolean checkAvailability(UserBean u) throws SQLException; // Checking
																		// seat
																		// availability

}
