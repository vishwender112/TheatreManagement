package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import DBconnect.DBConnect;
import Exception.HouseFull;
import Exception.NoSeatAvailability;
import src.UserBean;

/*
 *   Implementation of provided feature
 */

public class Dao implements UserDao {

	/*
	 * (non-Javadoc)
	 * 
	 * @see src.UserDao#bookTicket(src.User)
	 * 
	 * Ticket Booking
	 */

	public void bookTicket(UserBean u) throws SQLException {
		Connection conn = DBConnect.openConnection(); // connection object
		Statement st = conn.createStatement();
        Logger logger=Logger.getLogger("Dao");
PropertyConfigurator.configure("Log4j.properties");


		String sql = "insert into customer(name,mobileNo,movie,slot,seats,ticketId) values ( '" + u.getName() + "'"
				+ "," + "'" + u.getMobileNo() + "'" + "," + "'" + u.getMovie() + "'" + "," + "'" + u.getSlot() + "'"
				+ "," + u.getSeats() + "," + "ticketId.nextVal )";
		
		st.executeUpdate(sql);
		conn.commit();
        logger.info("Ticket is booked");
		ResultSet r = st
				.executeQuery("select " + u.getSlot() + " from seatMatrix where movies = " + "'" + u.getMovie() + "'");
		r.next();
		int seat = r.getInt(u.getSlot());
		seat = seat - u.getSeats();
		st.executeUpdate(
				"update seatMatrix set " + u.getSlot() + "=" + seat + " where Movies = " + "'" + u.getMovie() + "'");
		conn.commit();
		System.out.println("\n\nYour ticket has been booked !");
		r = st.executeQuery("select ticketId.currVal from customer");
		r.next();
		System.out.println("Name  = "+u.getName()+"\nMobileNo = "+u.getMobileNo()+"\nMovie Name= " + u.getMovie()+ "\nTimings= "+ u.getSlot()+"\nNo. of seats you have booked="+ u.getSeats());
		System.out.println("TicketId = " + r.getInt(1));
		System.out.println("Enjoy the show!!!");
		System.out.println("-------------------------");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see src.UserDao#delete(int)
	 * 
	 * Cancel Ticket
	 */
	public void delete(int ticketId) throws SQLException {
		Connection conn = DBConnect.openConnection();
		Statement st = conn.createStatement();
		Logger logger=Logger.getLogger("Dao");
        PropertyConfigurator.configure("Log4j.properties");

		String sql = "delete from customer where TICKETId=" + ticketId;
		st.executeUpdate(sql);
		conn.commit();
		//Log for deleting ticket
        logger.info("Ticket is deleted");

		System.out.println("successfully cancelled !");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see src.UserDao#checkAvailability(src.User)
	 * 
	 * Checking Availability of seats
	 */

	public boolean checkAvailability(UserBean u) throws SQLException {
		Connection conn = DBConnect.openConnection();

		Statement st = conn.createStatement();
		ResultSet r = st
				.executeQuery("select " + u.getSlot() + " from seatMatrix where movies = " + "'" + u.getMovie() + "'");

		r.next();
		int seat = r.getInt(u.getSlot());

		if (seat == 0) {
			try {
				throw new HouseFull(); // HouseFull Exception
			} catch (HouseFull blockBuster) {
				System.out.println(blockBuster);
			}
			return false;
		} else if (u.getSeats() > seat) {
			System.out.println("  Total seats available : " + seat);

			try {
				throw new NoSeatAvailability();
			} catch (NoSeatAvailability noseat) { // NoSeatAvailability
													// Exception
				System.out.println(noseat);
				System.out.println("----------------------------");
				System.out.println(" Try Again : ");
			}
			return false;
		} else
			return true;
	}

}
