package src;

import java.sql.SQLException;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import DAO.Dao;

public class UserLogin {

	public static void main(String[] args) throws SQLException {

        Logger logger=Logger.getLogger("UserLogin");
        PropertyConfigurator.configure("Log4j.properties");

		UserBean obj = new UserBean(); // Initializing user object
		Dao d = new Dao(); // Initializing Data access object
		Scanner input = new Scanner(System.in);
		Scanner name = new Scanner(System.in);
		int option = 0,option1, slotChoice, noOfTickets; // variable's for the switch
													// case

		System.out.println("------------------------------------------------------------");
		System.out.println();
		System.out.println("Welcome to the THEATRE BOOKING SYSTEM for the city of Delhi");
		System.out.println();
		System.out.println("----------------------------------------------------------");
		System.out.println();
		do {
			System.out.println();
			System.out.println("1. Book Ticket\n\n2. Cancel Ticket\n\n3. Exit\n\n Enter your choice: ");
            //Logging for entering the app
            logger.info("Entered the application");

			option = input.nextInt();
			if (option == 1) {
				do {
					System.out.println("Please input a movie to book the ticket ");
					System.out.println(
							"Please input 1 for Dangal @ PVR, 2 for Baahubali  @ DT Cinema, 3 for John Wick @ BIG Cinemas or 4 for Raees @ Cinepolis ");
					option1 = input.nextInt();

					switch (option1) { // Movie Choice
					case 1:
						obj.setMovie("Dangal");
						break;
					case 2:
						obj.setMovie("Baahubali");
						break;
					case 3:
						obj.setMovie("John Wick");
						break;
					case 4:
						obj.setMovie("Raees");
						break;
					default:
						System.out.println("wrong input!");

					}
				} while (option1 > 4 || option1 < 1);

				do {
					System.out.println();
					System.out.println(
							"Please input 1 for 9 am show, 2 for 12pm show, 3 for 3pm show or 4 for 6pm show ");
					slotChoice = input.nextInt();
					switch (slotChoice) { // Slot Choice
					case 1:
						obj.setSlot("Morning");
						break;
					case 2:
						obj.setSlot("Noon");
						break;
					case 3:
						obj.setSlot("Evening");
						break;
					case 4:
						obj.setSlot("Night");
						break;
					default:
						System.out.println("wrong input!");
						;
					}
				} while (slotChoice > 4 || slotChoice < 1);
				System.out.println();
				System.out.println("Enter the no. of tickets required");
				noOfTickets = input.nextInt();
				obj.setSeats(noOfTickets);

				boolean flag = d.checkAvailability(obj);
				if (flag == true) {
					System.out.println("Enter name: ");
					String name1 = name.nextLine();
					obj.setName(name1);
					System.out.println("Enter mobile no: ");
					String mob = input.nextLine();
					obj.setMobileNo(mob);
					d.bookTicket(obj);
				}
			} else if (option == 2) {
				System.out.println("Enter your ticketID: ");
				int del = input.nextInt();
				d.delete(del);
			} else if (option == 3)
				System.out.println("Thank you !");
			else
				System.out.println("Wrong input!");
		} while (option != 3);
		logger.info("Application exit");  
        //Logger for exit application


		input.close(); // closing scanner object
		name.close();

	}

}
