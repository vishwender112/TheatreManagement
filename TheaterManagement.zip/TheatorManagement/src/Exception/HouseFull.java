package Exception;

/*
 *  Exception ---> When all seats are booked
 */

public class HouseFull extends Exception {

	final static String message = " You can try some other slot . This Show is running HouseFull";

	@Override
	public String toString() {
		return "HouseFull [message=" + message + "]";
	}

}
