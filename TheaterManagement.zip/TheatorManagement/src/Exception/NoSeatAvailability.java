package Exception;

/*   
 *   Exception --->   When seats requested are more than seats available.
 */

public class NoSeatAvailability extends Exception {

	final static String message = "          :  Please try to book with in the availability !";

	@Override
	public String toString() {
		return "Message=" + message ;
	}

}
