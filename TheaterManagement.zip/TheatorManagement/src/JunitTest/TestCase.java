package JunitTest;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ClientLogin.UserBean;
import Exception.HouseFull;
import Exception.NoSeatAvailability;
import DAO.Dao;
import junit.framework.Assert;

public class TestCase {
	
	Dao d = new Dao(); 
	UserBean u = new UserBean();
	
	@Before
	public void init(){
		
		
		u.setName("raj");
		u.setMobileNo("456789");
		u.setSlot("Morning");
	}
	
	@Test
	public void testHousefull() throws SQLException {
		
		u.setMovie("Dangal");
		u.setSeats(10);
		
	    boolean b = d.checkAvailability(u);
	    System.out.println(b);
	    assertEquals(false, b);
		
	}
	
	@Test
	public void testSeatOrderedAreMore() throws SQLException{
		u.setMovie("John Wick");
		u.setSeats(60);
		boolean b = d.checkAvailability(u);
	    assertEquals(false, b);
		
	}
	
	@Test
	public void testSeatsAreAvailable() throws SQLException{
		u.setMovie("John Wick");
		boolean b = d.checkAvailability(u);
	    assertEquals(true, b);
	}

}
